angular.module("haikuEx.const", [])

.constant("VERSION", "0.0.0")

.constant("CONST", {
	"FB_URL": "http://pruvit.firebaseio.com/haikuEx"
})

;