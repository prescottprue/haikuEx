/*<?xml version="1.0"?>
<!DOCTYPE html
   PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "xhtml1-strict.dtd" [
   <!ATTLIST html
                   xmlns:xsi CDATA #IMPLIED
                   xsi:schemaLocation CDATA #IMPLIED>
]>
<html xmlns='http://www.w3.org/1999/xhtml'
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.w3.org/1999/xhtml datatype_normalization2.xsd"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/><title>datatype_normalization2</title></head><body onload="parent.loadComplete()">
 <p>
  <!--  preserve, string default  -->
  <em>    EMP  0001   </em>
  <!--   explicit preserve  -->
  <acronym>    EMP  0001   </acronym>
   <!--   explicit collapse  -->
  <code>
    EMP  0001
</code>
  <code>EMP  0001</code>
  <code>EMP 0001</code>
  <!--    explicit replace   -->
  <sup>
    EMP  0001
</sup>
  <sup>EMP  0001</sup>
  <sup>EMP 0001</sup>
  <sup>EMP
0001</sup>
  </p>
</body>
</html>*/
