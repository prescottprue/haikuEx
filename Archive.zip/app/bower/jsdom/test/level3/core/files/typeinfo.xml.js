/*<?xml version="1.0"?><?TEST-STYLE PIDATA?>
<!DOCTYPE html
   PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "xhtml1-strict.dtd"[
<!ATTLIST html
        xmlns:xsi CDATA #IMPLIED
        xsi:schemaLocation CDATA #IMPLIED>
]>
<html xmlns='http://www.w3.org/1999/xhtml'
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.w3.org/1999/xhtml typeinfo.xsd"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/><title>hc_staff</title></head>
        <body onload="parent.loadComplete()">
                 <p id="foo1"><strong>foo1 foo2</strong></p>
                 <p id="foo2"><code>1</code><code>unbounded</code></p>
                 <p><em>127</em><em>48</em></p>
                 <p><acronym>3.1415926 2.718</acronym></p>
         </body>
</html>
*/