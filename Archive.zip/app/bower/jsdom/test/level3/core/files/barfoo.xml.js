/*<!DOCTYPE html [
<!ENTITY ent1 'foo'>
<!ENTITY ent2 'foo<br/>'>
<!ELEMENT html (head, body)>
<!ATTLIST html xmlns CDATA #IMPLIED>
<!ELEMENT head (title,script*)>
<!ELEMENT script (#PCDATA)>
<!ATTLIST script 
     src CDATA #IMPLIED
     type CDATA #IMPLIED
     charset CDATA #IMPLIED>
<!ELEMENT title (#PCDATA)>
<!ELEMENT body (p)>
<!ATTLIST body onload CDATA #IMPLIED>
<!ELEMENT p (#PCDATA|br)*>
<!ELEMENT br EMPTY>
]>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<title>replaceWholeText sample</title>
</head>
<body onload="parent.loadComplete()">
<p>bar</p>
</body>
</html>*/
