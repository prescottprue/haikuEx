/*<!DOCTYPE svg [
<!ENTITY svgunit SYSTEM "svgunit.js">
<!ENTITY svgtest SYSTEM "svgtest.js">
<!ELEMENT svg (rect, script, data)>
<!ATTLIST svg 
	xmlns CDATA #IMPLIED
	xmlns:xsi CDATA #IMPLIED
	xsi:schemaLocation CDATA #IMPLIED>
   <!ELEMENT rect EMPTY>
   <!ATTLIST rect
      x CDATA #REQUIRED
      y CDATA #REQUIRED
      width CDATA #REQUIRED
      height CDATA #REQUIRED>
  <!ELEMENT script (#PCDATA)>
  <!ATTLIST script type CDATA #IMPLIED>
  <!ELEMENT data (double*, boolean*, decimal*, float*, dateTime*, time*)>
  <!ATTLIST data xmlns CDATA #IMPLIED>
  <!ELEMENT double (#PCDATA)>
  <!ATTLIST double 
        value CDATA #IMPLIED
        union CDATA #IMPLIED>
  <!ELEMENT boolean (#PCDATA)>
  <!ATTLIST boolean 
        value CDATA #IMPLIED
        union CDATA #IMPLIED>
  <!ELEMENT decimal (#PCDATA)>
  <!ATTLIST decimal 
        value CDATA #IMPLIED
        union CDATA #IMPLIED>
  <!ELEMENT float (#PCDATA)>
  <!ATTLIST float 
        value CDATA #IMPLIED
        union CDATA #IMPLIED>
  <!ELEMENT dateTime (#PCDATA)>
  <!ATTLIST dateTime 
        value CDATA #IMPLIED
        union CDATA #IMPLIED>
  <!ELEMENT time (#PCDATA)>
  <!ATTLIST time 
        value CDATA #IMPLIED
        union CDATA #IMPLIED>

]>
<svg xmlns="http://www.w3.org/2000/svg" 	
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://www.w3.org/2000/svg datatype_normalization.svg.xsd">
<rect x="0" y="0" width="100" height="100"/><script type="text/ecmascript">&svgtest;&svgunit;</script>
<data xmlns='http://www.w3.org/2001/DOM-Test-Suite/Level-3/datatype_normalization'>
<double value=" 
 +0003.141592600E+0000 " union="  +0003.141592600E+0000  
 ">   -31415926.00E-7
2.718</double>
<double value=" NaN" union="NaN "> INF    -INF </double>
<double value="
1 " union="1
"> -0</double>
<boolean value=" 
 true" union="false 
 "> false true       false </boolean>
<boolean value="
 1" union=" 0
 ">0 1     0 </boolean>
<decimal value="  +0003.141592600  " union="  +0003.141592600  ">  +10 .1  </decimal>
<decimal value=" 01 " union=" 01 "> -.001 </decimal>
<float value=" +0003.141592600E+0000 " union=" +0003.141592600E+0000 "> -31415926.00E-7
2.718</float>
<float value=" NaN " union=" NaN "> INF    -INF </float>
<float value="
1 " union="1
">-0</float>
<dateTime value="
2004-01-21T15:30:00-05:00" union="2004-01-21T20:30:00-05:00
">2004-01-21T15:30:00
2004-01-21T15:30:00Z</dateTime>
<dateTime value="
2004-01-21T15:30:00.0000-05:00" union="2004-01-21T15:30:00.0000-05:00
">  2004-01-21T15:30:00.0000  </dateTime>
<dateTime value="2004-01-21T15:30:00.0001-05:00" union="2004-01-21T15:30:00.0001-05:00">2004-01-21T15:30:00.0001</dateTime>
<time value="
15:30:00-05:00" union="15:30:00-05:00
"> 15:30:00 </time>
<time value="
 15:30:00.0000-05:00" union=" 15:30:00.0000-05:00
 ">15:30:00.0000</time>
<time value="
 15:30:00.0001-05:00" union="15:30:00.0001-05:00
 ">15:30:00.0001</time>
</data>
</svg>*/