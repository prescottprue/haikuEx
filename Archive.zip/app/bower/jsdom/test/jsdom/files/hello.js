document.getElementById("test").innerHTML = "hello from javascript";
window.doCheck();
