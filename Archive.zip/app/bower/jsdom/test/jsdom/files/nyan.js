document.getElementById("cat").innerHTML = "hello from nyan cat";
